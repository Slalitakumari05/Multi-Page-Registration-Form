
// function for validation
function validate() {
  // variable decleration
  var name = document.getElementById("fname");
  var lname = document.getElementById("lname");
  var fathername = document.getElementById("fathername");
  var mothername = document.getElementById("mothername");
  var gender = document.getElementById("gender");
  var nationality = document.getElementById("nationality");
  var Address = document.getElementById("Address");
  var mobile = document.getElementById("mobile");
  var telnumber = document.getElementById("telnumber");
  var country=document.getElementById("country");

  //    decleartion
  if (name.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (lname.value.trim() == "") {
    alert("Blank Last Name");
    return false;
  } else if (fathername.value.trim() == "") {
    alert("Blank Father Name");
    return false;
  } else if (mothername.value.trim() == "") {
    alert("Blank Mother Name");
    return false;
  } else if (gender.value.trim() == "") {
    alert("Choose gender");
    return false;
  } else if (nationality.value.trim() == "") {
    alert("Enter Nationality");
    return false;
  } else if (Address.value.trim() == "") {
    alert("please Enter Address");
    return false;
  } else if (mobile.value.trim().length ==10) {
    alert("mobile no should be 10 digits");
    return false;
  } else if (telnumber.value.trim().length ==10) {
    alert("Telephone  no should be 10 digits");
    return false;
  }
}
function validate2() {
  var HSCInstitutionName = document.getElementById("HSCInstitutionName");
  var HSCBoard = document.getElementById("HSCBoard");
  var score = document.getElementById("score");
  var SSCInstitutionName = document.getElementById("SSCInstitutionname");
  var SSCBoard = document.getElementById("SSCBoard");
  var SSCpercentage = document.getElementById("SSCpercentage");
  var pursuing = document.getElementById("pursuing");
  var institutename = document.getElementById("institutename");
  var percentage = document.getElementById("percentage");
  var backlogs = document.getElementById("backlogs");

  if (HSCInstitutionName.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (HSCBoard.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (score.value.trim() == "") {
    alert("score should be digits");
    return false;
  } else if (SSCInstitutionName.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (SSCBoard.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (SSCpercentage.value.trim() == "") {
    alert("score should be digits");
    return false;
  } else if (pursuing.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (institutename.value.trim() == "") {
    alert("Blank Name");
    return false;
  } else if (percentage.value.trim() == "") {
    alert("score should be digits");
    return false;
  } else if (backlogs.value.trim() == "") {
    alert("backlogs");
    return false;
  }
}

